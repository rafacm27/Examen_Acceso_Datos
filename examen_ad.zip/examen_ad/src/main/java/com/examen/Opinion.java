package com.examen;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name = "opinion")
public class Opinion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false, length = 500)
    private String descripcion;

    @NotBlank
    @Column(nullable = false, length = 200)
    private String usuario;

    @Min(0)
    @Max(10)
    @Column(nullable = false)
    private int puntuacion;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pelicula_id", nullable = false)
    private Pelicula pelicula;

    public Opinion() {}

    public Opinion(String descripcion, String usuario, int puntuacion) {
        this.descripcion = descripcion;
        this.usuario = usuario;
        setPuntuacion(puntuacion);
    }

    public void setPuntuacion(int puntuacion) {
        if (puntuacion < 0 || puntuacion > 10) {
            throw new IllegalArgumentException("La puntuación debe estar entre 0 y 10");
        }
        this.puntuacion = puntuacion;
    }

    public Long getId() { return id; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }
    public int getPuntuacion() { return puntuacion; }
    public Pelicula getPelicula() { return pelicula; }
    public void setPelicula(Pelicula pelicula) { this.pelicula = pelicula; }

    @Override
    public String toString() {
        return "Opinion{id=" + id + ", usuario='" + usuario + "', puntuacion=" + puntuacion + "}";
    }
}
