package com.examen;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        DataService service = new DataService();

        Pelicula p1 = service.registrarPelicula("Interstellar");
        Pelicula p2 = service.registrarPelicula("The Room");
        Pelicula p3 = service.registrarPelicula("Cats");

        service.anadirOpinionAPelicula(p1.getId(), "Brutal ciencia y emoción", "ana@example.com", 9);
        service.anadirOpinionAPelicula(p1.getId(), "Demasiado larga", "pepe@example.com", 6);

        service.anadirOpinionAPelicula(p2.getId(), "Obra maestra del mal cine", "ana@example.com", 2);
        service.anadirOpinionAPelicula(p2.getId(), "Me reí sin querer", "luis@example.com", 3);

        service.anadirOpinionAPelicula(p3.getId(), "No entendí nada", "ana@example.com", 1);

        List<Opinion> opinionesAna = service.obtenerOpinionesPorUsuario("ana@example.com");
        System.out.println("Opiniones de ana@example.com:");
        opinionesAna.forEach(System.out::println);

        List<String> bajas = service.listarPeliculasConBajaPuntuacion();
        System.out.println("Películas con al menos una opinión <= 3:");
        bajas.forEach(System.out::println);

        HibernateUtil.shutdown();
    }
}
