package com.examen;

import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;


public class DataService {

    public Pelicula registrarPelicula(String titulo) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            Pelicula pelicula = new Pelicula(titulo);
            session.persist(pelicula);
            tx.commit();
            return pelicula;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw e;
        }
    }

    public List<Opinion> obtenerOpinionesPorUsuario(String correoUsuario) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "from Opinion o where o.usuario = :correo order by o.id",
                    Opinion.class
            ).setParameter("correo", correoUsuario).getResultList();
        }
    }

    public Opinion anadirOpinionAPelicula(long peliculaId, String descripcion, String usuario, int puntuacion) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();

            Pelicula pelicula = session.get(Pelicula.class, peliculaId);
            if (pelicula == null) {
                throw new IllegalArgumentException("No existe la película con id " + peliculaId);
            }

            Opinion opinion = new Opinion(descripcion, usuario, puntuacion);
            pelicula.addOpinion(opinion);

            session.persist(opinion);
            session.merge(pelicula);

            tx.commit();
            return opinion;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw e;
        }
    }

    public List<String> listarPeliculasConBajaPuntuacion() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "select distinct p.titulo from Pelicula p join p.opiniones o where o.puntuacion <= 3 order by p.titulo",
                    String.class
            ).getResultList();
        }
    }
}
