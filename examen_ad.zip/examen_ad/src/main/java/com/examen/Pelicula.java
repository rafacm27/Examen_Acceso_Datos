package com.examen;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "pelicula")
public class Pelicula {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 200)
    private String titulo;

    @OneToMany(mappedBy = "pelicula", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<Opinion> opiniones = new ArrayList<>();

    public Pelicula() {}

    public Pelicula(String titulo) {
        this.titulo = titulo;
    }

    public void addOpinion(Opinion opinion) {
        opiniones.add(opinion);
        opinion.setPelicula(this);
    }

    public void removeOpinion(Opinion opinion) {
        opiniones.remove(opinion);
        opinion.setPelicula(null);
    }

    public Long getId() { return id; }
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public List<Opinion> getOpiniones() { return opiniones; }

    @Override
    public String toString() {
        return "Pelicula{id=" + id + ", titulo='" + titulo + "'}";
    }
}
